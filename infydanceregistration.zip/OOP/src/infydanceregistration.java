public class infydanceregistration {
	private static int counter = 10000;
	private String name;
	private long contactnumber;
	private String city;
	
	public infydanceregistration(String name, long contactnumber, String city) {
		super();
		this.name = name;
		this.contactnumber = contactnumber;
		this.city = city;
	}

	
	public String getName() {
		return name;
	}

	public String generateregistrationid () {
		counter++;
		String id = "Hi "+ getName()+'.' +" Your Registration id is: "+ 'D'+counter;
		return id;
		
	}
	
	
	

}
